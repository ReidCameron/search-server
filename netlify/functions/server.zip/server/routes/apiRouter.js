var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var apiRouter_exports = {};
__export(apiRouter_exports, {
  default: () => apiRouter_default
});
module.exports = __toCommonJS(apiRouter_exports);
var import_express = require("express");
var import_search = require("../handlers/search");
var import_payload = __toESM(require("../misc/payload"), 1);
const router = (0, import_express.Router)();
router.use((0, import_express.json)({ limit: "1mb" }));
router.get("/", async (req, res, next) => {
  res.json({ "message": "Search Server API" });
});
router.get("/search", async (req, res, next) => {
  console.time("Total");
  try {
    await (0, import_search.handler)({ body: import_payload.default, res });
  } catch (error) {
    next(error);
  }
  console.timeEnd("Total");
  return;
});
router.post("/search", async (req, res, next) => {
  console.time("Total");
  try {
    console.time("Parse Post Body");
    const bodyJson = JSON.parse(req.body.toString());
    console.timeEnd("Parse Post Body");
    await (0, import_search.handler)({ body: bodyJson, res });
  } catch (error) {
    next(error);
  }
  console.timeEnd("Total");
  return;
});
router.use((req, res) => {
  res.status(404).json({ "message": "Endpoint does not exist." });
});
var apiRouter_default = router;
