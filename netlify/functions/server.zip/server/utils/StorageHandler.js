var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var StorageHandler_exports = {};
__export(StorageHandler_exports, {
  StorageHandler: () => StorageHandler
});
module.exports = __toCommonJS(StorageHandler_exports);
var import_blobs = require("@netlify/blobs");
class StorageHandler {
  static TOKEN_STORE = "tokens";
  #cache = { stores: {} };
  async get({ store, key, opts }) {
    return this.#getCachedStore(store).get(key, { ...opts });
  }
  async set({ store, key, value }) {
    return this.#getCachedStore(store).setJSON(key, value);
  }
  #getCachedStore(storeName) {
    return this.#cache.stores[storeName] ?? (this.#cache.stores[storeName] = {
      store: (0, import_blobs.getStore)(storeName),
      values: {},
      get: async function(key, opts) {
        return this.values[key] ?? (this.values[key] = await this.store.get(key, opts));
      },
      setJSON: function(key, value) {
        this.values[key] = value;
        return this.store.setJSON(key, value);
      }
    });
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  StorageHandler
});
