var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var gqlQueries_exports = {};
__export(gqlQueries_exports, {
  buildFilesQuery: () => buildFilesQuery,
  buildProductQuery: () => buildProductQuery,
  getCurrencies: () => getCurrencies
});
module.exports = __toCommonJS(gqlQueries_exports);
var import_functions = require("./functions.js");
function buildProductQuery(results, config = {}) {
  return {
    query: `query GetProducts{
            shop{
                moneyFormat
            }
            ${//TODO: Need to determine config structure and proper input args
    config.metaobjects?.enable ? `metaobject(handle: {handle:"app--337510563841--athos_color_mapping"}){
                        field
                    }` : ""}
            ${results.map((result, index) => {
      return buildResultSubQuery(index, (0, import_functions.handleize)(result.name));
    }).join("")}
        }`
  };
}
function buildResultSubQuery(index, handle) {
  return `result_${index}: product(handle: "${handle}"){
            id
            handle
            title
            vendor
            totalInventory
            availableForSale
            featuredImage {
                url
                altText
            }
            images(first: 5) {
                nodes {
                    url
                    altText
                }
            }
            priceRange {
                maxVariantPrice {
                    amount
                }
                minVariantPrice {
                    amount
                }
            }
            compareAtPriceRange {
                maxVariantPrice {
                    amount
                }
                minVariantPrice {
                    amount
                }
            }
            variants(first: 15) {
                nodes {
                    id
                    title
                    sku
                    quantityAvailable
                    availableForSale
                    image {
                        url
                        altText
                    }
                    price {
                        amount
                    }
                    compareAtPrice {
                        amount
                    }
                }
            }
        }
    `;
}
function getCurrencies() {
  return `shop{
            currencyFormats{
                moneyFormat
                moneyWithCurrencyFormat
            }
        }
    `;
}
function buildFilesQuery(config) {
  return {
    query: `query getFiles($id: ID!, $filenames: [String!]) {
            theme(id: $id) {
                id
                name
                role
                files(filenames: $filenames) {
                    nodes {
                        filename
                        body {
                            ... on OnlineStoreThemeFileBodyText {
                                content
                            }
                        }
                    }
                }
            }
        }`,
    variables: {
      id: "gid://shopify/OnlineStoreTheme/" + config.id,
      filenames: config.filenames
    }
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildFilesQuery,
  buildProductQuery,
  getCurrencies
});
