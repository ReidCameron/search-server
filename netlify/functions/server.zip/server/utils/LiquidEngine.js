var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var LiquidEngine_exports = {};
__export(LiquidEngine_exports, {
  LiquidEngine: () => LiquidEngine
});
module.exports = __toCommonJS(LiquidEngine_exports);
var import_liquidjs = __toESM(require("liquidjs"), 1);
class LiquidEngine {
  #fileStore = {};
  #engine;
  #templates = {};
  #hasTemplates = false;
  constructor(options) {
    const fileStore = this.#fileStore;
    this.#engine = new import_liquidjs.default.Liquid({
      fs: {
        readFileSync(file) {
          return fileStore[file];
        },
        async readFile(file) {
          return Promise.resolve(fileStore[file]);
        },
        existsSync() {
          return true;
        },
        async exists() {
          return true;
        },
        contains() {
          return true;
        },
        resolve(root, file, ext) {
          return file;
        }
      }
    });
    if (typeof options?.customFilters == "function") {
      options.customFilters(this.#engine);
    }
  }
  async parseFile(fileName, useCacheTemplates = true) {
    if (useCacheTemplates && Object.hasOwn(this.#templates, fileName)) return this.#templates[fileName];
    const tpl = await this.#engine.parseFile(fileName);
    this.#templates[fileName] = tpl;
    this.#hasTemplates = true;
    return tpl;
  }
  async renderFileWithContext(fileName, context) {
    if (this.#templates[fileName]) {
      return this.#engine.render(this.#templates[fileName], context);
    } else {
      return Promise.resolve("");
    }
  }
  addFiles(files) {
    Object.assign(this.#fileStore, files);
  }
  //Read Only
  get hasTemplates() {
    return this.#hasTemplates;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  LiquidEngine
});
