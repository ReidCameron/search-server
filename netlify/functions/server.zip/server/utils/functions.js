var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var functions_exports = {};
__export(functions_exports, {
  buildUrl: () => buildUrl,
  handleize: () => handleize
});
module.exports = __toCommonJS(functions_exports);
function buildUrl(url, paramEntries) {
  const newURL = new URL(url);
  for (const [key, value] of paramEntries) {
    if (key.startsWith("filter.") || key.startsWith("sort.")) {
      if (value.includes(":")) {
        const [low, high] = value.split(":");
        newURL.searchParams.append(key + ".low", low);
        newURL.searchParams.append(key + ".high", high);
      } else {
        newURL.searchParams.append(key, value);
      }
    } else if (key != "domain") {
      newURL.searchParams.set(key, value);
    }
  }
  return newURL.toString();
}
function handleize(str) {
  return str.toLowerCase().replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#039;/g, "'").normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9\s-]/g, "").trim().replace(/\s+/g, "-").replace(/-+/g, "-");
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  buildUrl,
  handleize
});
