var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var ShopifyAPIClient_exports = {};
__export(ShopifyAPIClient_exports, {
  ShopifyAPIClient: () => ShopifyAPIClient
});
module.exports = __toCommonJS(ShopifyAPIClient_exports);
var import_admin_api_client = require("@shopify/admin-api-client");
var import_storefront_api_client = require("@shopify/storefront-api-client");
var import_StorageHandler = require("./StorageHandler.js");
var import_dotenv = __toESM(require("dotenv"), 1);
import_dotenv.default.config({ path: process.cwd() + "/.env" });
class ShopifyAPIClient {
  static defaultVersion = "2026-04";
  #storeDomain;
  #storageHandler;
  #admin;
  #storefront;
  constructor({ store, storageHandler, admin, storefront }) {
    this.#storeDomain = store;
    this.#storageHandler = storageHandler;
    this.#admin = admin;
    this.#storefront = storefront;
  }
  static async create({ store, storageHandler }) {
    const client = new ShopifyAPIClient({ store, storageHandler });
    await client.#initClients();
    return client;
  }
  async #initClients() {
    console.time(" (CC) Load Tokens");
    const { access_token } = await this.#loadTokens();
    console.timeEnd(" (CC) Load Tokens");
    const apiVersion = ShopifyAPIClient.defaultVersion;
    this.#admin = (0, import_admin_api_client.createAdminApiClient)({
      storeDomain: this.#storeDomain,
      apiVersion,
      accessToken: access_token
    });
    this.#storefront = (0, import_storefront_api_client.createStorefrontApiClient)({
      storeDomain: this.#storeDomain,
      apiVersion,
      privateAccessToken: access_token
    });
  }
  async #loadTokens() {
    const { access_token, expires_at, refresh_token } = await this.#storageHandler.get(
      {
        store: import_StorageHandler.StorageHandler.TOKEN_STORE,
        key: this.#storeDomain,
        opts: { type: "json" }
      }
    ) || {};
    if (!access_token || expires_at < Date.now()) {
      return await this.#requestNewTokens(refresh_token ?? process.env.INITIAL_SHOPIFY_REFRESH_TOKEN);
    }
    return { access_token };
  }
  async #requestNewTokens(refreshToken) {
    const res = await fetch(`https://${this.#storeDomain}/admin/oauth/access_token`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        client_id: process.env.SHOPIFY_CLIENT_ID,
        client_secret: process.env.SHOPIFY_CLIENT_SECRET,
        grant_type: "refresh_token",
        refresh_token: refreshToken
      })
    });
    const res_json = await res.json();
    const { expires_in, refresh_token_expires_in } = res_json;
    const now = Date.now();
    Object.assign(res_json, { expires_at: now + expires_in * 1e3, refresh_token_expires_at: now + refresh_token_expires_in * 1e3 });
    this.#storageHandler.set({ store: import_StorageHandler.StorageHandler.TOKEN_STORE, key: this.#storeDomain, value: res_json });
    return res_json;
  }
  //Read Only
  get admin() {
    return this.#admin;
  }
  get storefront() {
    return this.#storefront;
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ShopifyAPIClient
});
