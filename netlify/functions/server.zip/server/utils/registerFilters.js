var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var registerFilters_exports = {};
__export(registerFilters_exports, {
  registerFilters: () => registerFilters
});
module.exports = __toCommonJS(registerFilters_exports);
function registerFilters(engine) {
  const globalContext = this.globalContext;
  engine.registerFilter("image_url", function(product, width, height) {
    const width2Num = +width || 0;
    const height2Num = +height || 0;
    return product.featured_image.url + (width2Num ? `&width=${width2Num}` : "") + (height2Num ? `&height=${height2Num}` : "");
  });
  engine.registerFilter("money", function(amount) {
    return globalContext.money_format.replace("{{amount}}", amount);
  });
  engine.registerFilter("money_amount", function(amount) {
    return amount;
  });
  engine.registerFilter("money_with_currency", function(amount) {
    return "not yet implemented";
    return globalContext.money_format.replace("{{amount}}", amount) + globalContext.currency;
  });
  engine.registerFilter("money_without_currency", function(amount) {
    return globalContext.money_format.replace("{{amount}}", amount);
  });
  engine.registerFilter("money_without_trailing_zeros", function(amount) {
    return globalContext.money_format.replace("{{amount}}", amount.replace(/(\.|,)0+$/, ""));
  });
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  registerFilters
});
