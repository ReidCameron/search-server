var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var search_exports = {};
__export(search_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(search_exports);
var import_dotenv = __toESM(require("dotenv"), 1);
var import_gqlQueries = require("../utils/gqlQueries.js");
var import_functions = require("../utils/functions.js");
var import_registerFilters = require("../utils/registerFilters.js");
var import_LiquidEngine = require("../utils/LiquidEngine.js");
var import_ShopifyAPIClient = require("../utils/ShopifyAPIClient.js");
var import_getBlockContext = require("../utils/getBlockContext.js");
var import_StorageHandler = require("../utils/StorageHandler.js");
import_dotenv.default.config({ path: process.cwd() + "/.env" });
const globalContext = {};
const liquidEngine = new import_LiquidEngine.LiquidEngine({ customFilters: import_registerFilters.registerFilters.bind({ globalContext }) });
const storageHandler = new import_StorageHandler.StorageHandler();
async function handler({ body, res }) {
  console.time("Validaiton");
  if (!Array.isArray(body.apiParams) || !Array.isArray(body.blockSettings) || typeof body.sectionSettings !== "object" || typeof body.siteId !== "string") {
    return res.status(400).send(
      "Post body for 'hydrate' op must be a JSON object with the properties 'apiParams'[Array], 'blockSettings'[Array], 'sectionSettings'[Object], and 'siteId'[String]."
    );
  }
  console.timeEnd("Validaiton");
  console.time("Create Client");
  const shopifyApiClient = await import_ShopifyAPIClient.ShopifyAPIClient.create({ store: "my-test-store-123456789142.myshopify.com", storageHandler });
  console.timeEnd("Create Client");
  console.time("Get Data and Templates");
  let contextAndTemplates;
  try {
    contextAndTemplates = await Promise.all([getContext(body, shopifyApiClient.storefront), getTemplates(body, shopifyApiClient.admin)]);
  } catch (error) {
    console.log({ msg: error.message });
    return res.status(500).send("Something went wrong with an upstream service.");
  }
  console.timeEnd("Get Data and Templates");
  console.time("Build Context and Render");
  const { apiData, gqlData } = contextAndTemplates[0];
  Object.assign(globalContext, getGlobalContext({ apiData, gqlData, body }));
  const renderedComponents = [];
  await Promise.all(
    body.blockSettings.map(async (block, index) => {
      const fileName = block.type.replaceAll("_", "-");
      const localContext = (0, import_getBlockContext.getBlockContext)(block, body.sectionSettings, body.apiParams, apiData, gqlData);
      const context = {
        ...globalContext,
        //Data that each component might use (shop, fonts, colors, etc.)
        ...localContext,
        //Settings unique to each component (products, pagiation data, etc.)
        section: { settings: body.sectionSettings },
        //Section settings conifugred in the theme editor
        block: { settings: block.settings }
        //Block settings conifugred in the theme editor
      };
      const markup = await liquidEngine.renderFileWithContext(fileName, context);
      renderedComponents.push({
        type: block.type,
        content: markup.replace(/\n|\s{2,}/g, ""),
        selector: block.settings.selector
      });
    })
  );
  console.timeEnd("Build Context and Render");
  return res.json({
    op: "search",
    components: renderedComponents
  });
}
const getContext = async (body, storefrontClient) => {
  console.time(" (GDaT) Get Data");
  console.time("   (GD) API Search");
  const apiData = await getAPIData(body);
  console.timeEnd("   (GD) API Search");
  console.time("   (GD) GQL Search");
  const gqlData = await getShopifyProductData(apiData, storefrontClient);
  console.timeEnd("   (GD) GQL Search");
  console.timeEnd(" (GDaT) Get Data");
  return { apiData, gqlData };
};
async function getAPIData(body) {
  const apiRequestUrl = (0, import_functions.buildUrl)(`https://${body.siteId}.a.searchspring.io/api/search/search.json`, body.apiParams);
  const res = await fetch(apiRequestUrl);
  return await res.json();
}
async function getShopifyProductData(apiData, storefrontClient) {
  const { query } = (0, import_gqlQueries.buildProductQuery)(apiData.results);
  const { data, errors } = await storefrontClient.request(query);
  if (errors) {
    console.error({ "GQL ERROR MSG:": errors.message });
    console.dir(errors.graphQLErrors, { depth: 4 });
  }
  return data;
}
const getTemplates = async (body, adminClient) => {
  console.time(" (GDaT) Get Templates");
  if (body.custom?.enableCustomTemplates || liquidEngine.hasTemplates) {
    console.timeEnd(" (GDaT) Get Templates");
    return Promise.resolve();
  }
  const files = await getShopifyFiles(adminClient, body.themeId);
  liquidEngine.addFiles(files);
  const tpls = await Promise.all(
    body.blockSettings.map((block) => {
      const fileName = block.type.replaceAll("_", "-");
      return liquidEngine.parseFile(fileName, true);
    })
  );
  console.timeEnd(" (GDaT) Get Templates");
  return tpls;
};
async function getShopifyFiles(adminClient, themeId) {
  const { query, variables } = (0, import_gqlQueries.buildFilesQuery)({
    id: themeId,
    //TODO: supply filenames from default config, or config from theme
    filenames: [
      //Header
      "snippets/athos-header.liquid",
      //Toolbar
      "snippets/athos-toolbar.liquid",
      //Results
      "snippets/athos-results.liquid",
      "snippets/athos-result.liquid",
      //Sidebar
      "snippets/athos-sidebar.liquid",
      "snippets/athos-facet.liquid",
      "snippets/athos-facet.liquid-options.liquid",
      "snippets/athos-facet.liquid-options-grid.liquid",
      "snippets/athos-facet.liquid-options-hierarchy.liquid",
      "snippets/athos-facet.liquid-options-list.liquid",
      "snippets/athos-facet.liquid-options-palette.liquid",
      "snippets/athos-facet.liquid-options-slider.liquid",
      //Pagination
      "snippets/athos-pagination.liquid",
      "snippets/athos-pagination-infinite.liquid",
      "snippets/athos-pagination-load-more.liquid",
      "snippets/athos-pagination-numbered.liquid"
    ]
  });
  const { data, errors } = await adminClient.request(query, { variables });
  if (errors) {
    console.error({ "GQL ERROR MSG:": errors.message });
    console.dir(errors.graphQLErrors, { depth: 4 });
  }
  return Object.fromEntries(data.theme.files.nodes.map((node) => {
    return [node.filename.match(/(?<=\/)[^/]+(?=\.)/)?.[0], node.body.content];
  }));
}
function getGlobalContext({ apiData, gqlData, body }) {
  return {
    /* API Related */
    siteId: body.siteId,
    /* Supplemental GQL Data*/
    money_format: gqlData.shop.moneyFormat
  };
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
